/**
 * Created by mihir on 25-02-2018.
 */
function meat_selections_edit() {
    if (document.getElementById("meat_selections").selectedIndex == 0) {
        document.getElementById("meat_sup_num").innerHTML = "First Supplier";
        document.getElementById("meat_st_num").innerHTML = "Stock-00001";
        document.getElementById("meat_st_item").innerHTML = "First Stock Item";
        document.getElementById("meat_pp_item").innerHTML = "$2,000";
        document.getElementById("meat_sp_item").innerHTML = "$2,200";
        document.getElementById("meat_quantity").innerHTML = "540";

    }
    else if (document.getElementById("meat_selections").selectedIndex == 1) {
        document.getElementById("meat_sup_num").innerHTML = "Second Supplier";
        document.getElementById("meat_st_num").innerHTML = "Stock-00002";
        document.getElementById("meat_st_item").innerHTML = "Second Stock Item";
        document.getElementById("meat_pp_item").innerHTML = "$2,100";
        document.getElementById("meat_sp_item").innerHTML = "$2,300";
        document.getElementById("meat_quantity").innerHTML = "234";


    }
    else if (document.getElementById("meat_selections").selectedIndex == 2)
    {
        document.getElementById("meat_sup_num").innerHTML ="Third Supplier";
        document.getElementById("meat_st_num").innerHTML ="Stock-00003";
        document.getElementById("meat_st_item").innerHTML ="Third Stock Item";
        document.getElementById("meat_pp_item").innerHTML ="$2,200";
        document.getElementById("meat_sp_item").innerHTML ="$,4200";
        document.getElementById("meat_quantity").innerHTML ="342";

    }


    else
    {
        document.getElementById("meat_sup_num").innerHTML ="Fourth Supplier";
        document.getElementById("meat_st_num").innerHTML ="Stock-00004";
        document.getElementById("meat_st_item").innerHTML ="Fourth Stock Item";
        document.getElementById("meat_pp_item").innerHTML ="$2,300";
        document.getElementById("meat_sp_item").innerHTML ="$2,500";
        document.getElementById("meat_quantity").innerHTML ="210";
    }

}

function veg_selections_edit() 
{
    if (document.getElementById("veg_selections").selectedIndex == 0)
    {
        document.getElementById("veg_sup_num").innerHTML = "Fifth Supplier";
        document.getElementById("veg_st_num").innerHTML = "Stock-00005";
        document.getElementById("veg_st_item").innerHTML = "Fifth Stock Item";
        document.getElementById("veg_pp_item").innerHTML = "$900";
        document.getElementById("veg_sp_item").innerHTML = "$1,200";
        document.getElementById("veg_quantity").innerHTML = "840";

    }
    else if (document.getElementById("veg_selections").selectedIndex == 1)
    {
        document.getElementById("veg_sup_num").innerHTML = "Sixth Supplier";
        document.getElementById("veg_st_num").innerHTML = "Stock-00006";
        document.getElementById("veg_st_item").innerHTML = "Sixth Stock Item";
        document.getElementById("veg_pp_item").innerHTML = "$920";
        document.getElementById("veg_sp_item").innerHTML = "$1,120";
        document.getElementById("veg_quantity").innerHTML = "207";


    }
    else if (document.getElementById("veg_selections").selectedIndex == 2)
    {
        document.getElementById("veg_sup_num").innerHTML ="Seventh Supplier";
        document.getElementById("veg_st_num").innerHTML ="Stock-00007";
        document.getElementById("veg_st_item").innerHTML ="Seventh Stock Item";
        document.getElementById("veg_pp_item").innerHTML ="$970";
        document.getElementById("veg_sp_item").innerHTML ="$1,270";
        document.getElementById("veg_quantity").innerHTML ="321";

    }


    else
    {
        document.getElementById("veg_sup_num").innerHTML ="Eight Supplier";
        document.getElementById("veg_st_num").innerHTML ="Stock-00008";
        document.getElementById("veg_st_item").innerHTML ="Eight Stock Item";
        document.getElementById("veg_pp_item").innerHTML ="$990";
        document.getElementById("veg_sp_item").innerHTML ="$1,290";
        document.getElementById("veg_quantity").innerHTML ="271";
    }
}



function fruit_selections_edit()
{
    if (document.getElementById("fruit_selections").selectedIndex == 0)
    {
        document.getElementById("fruit_sup_num").innerHTML = "Ninth Supplier";
        document.getElementById("fruit_st_num").innerHTML = "Stock-00009";
        document.getElementById("fruit_st_item").innerHTML = "Ninth Stock Item";
        document.getElementById("fruit_pp_item").innerHTML = "$750";
        document.getElementById("fruit_sp_item").innerHTML = "$900";
        document.getElementById("fruit_quantity").innerHTML = "450";

    }


    else if (document.getElementById("fruit_selections").selectedIndex == 1)
    {
        document.getElementById("fruit_sup_num").innerHTML = "Tenth Supplier";
        document.getElementById("fruit_st_num").innerHTML = "Stock-00010";
        document.getElementById("fruit_st_item").innerHTML = "Tenth Stock Item";
        document.getElementById("fruit_pp_item").innerHTML = "$790";
        document.getElementById("fruit_sp_item").innerHTML = "$920";
        document.getElementById("fruit_quantity").innerHTML = "137";
    }



    else if (document.getElementById("fruit_selections").selectedIndex == 2)
    {
        document.getElementById("fruit_sup_num").innerHTML = "Eleventh Supplier";
        document.getElementById("fruit_st_num").innerHTML = "Stock-00011";
        document.getElementById("fruit_st_item").innerHTML = "Eleventh Stock Item";
        document.getElementById("fruit_pp_item").innerHTML = "$820";
        document.getElementById("fruit_sp_item").innerHTML = "$970";
        document.getElementById("fruit_quantity").innerHTML = "372";
    }

    else
    {
        document.getElementById("fruit_sup_num").innerHTML = "Twelfth Supplier";
        document.getElementById("fruit_st_num").innerHTML = "Stock-00012";
        document.getElementById("fruit_st_item").innerHTML = "Twelfth Stock Item";
        document.getElementById("fruit_pp_item").innerHTML = "$860";
        document.getElementById("fruit_sp_item").innerHTML = "$1,110";
        document.getElementById("fruit_quantity").innerHTML = "287";
    }



}








