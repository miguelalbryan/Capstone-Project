/**
 * Created by mihir on 16-03-2018.
 */
function week_selection_edit ()
{
 if(document.getElementById("week_selection").selectedIndex ==0)
 {
     document.getElementById("Week_no").innerHTML = "Week 1";
     document.getElementById("Item_no").innerHTML = "3";
     document.getElementById("Total_waste").innerHTML = "30Kg";
     document.getElementById("Item_sold").innerHTML = "23";
     document.getElementById("Current_invoice").innerHTML = "500";

 }
     else if (document.getElementById("week_selection").selectedIndex ==1)
    {

        document.getElementById("Week_no").innerHTML = "Week 2";
        document.getElementById("Item_no").innerHTML = "4";
        document.getElementById("Total_waste").innerHTML = "25Kg";
        document.getElementById("Item_sold").innerHTML = "21";
        document.getElementById("Current_invoice").innerHTML = "700";
    }


        else
     {
         document.getElementById("Week_no").innerHTML = "Week 3";
         document.getElementById("Item_no").innerHTML = "5";
         document.getElementById("Total_waste").innerHTML = "20Kg";
         document.getElementById("Item_sold").innerHTML = "19";
         document.getElementById("Current_invoice").innerHTML = "600";
     }

}