<?php
$dir = 'rpt/';
$files1 = scandir($dir);
$i = count($files1)-1;
  $myfile = fopen("rpt/$i.html", "w");
  $txt = "<table id=\"meat-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>Pork</td>
          <td>lbs</td>
          <td>357.898</td>
          <td>2149.432</td>
          <td>245.194</td>
          <td>2253.966</td>
          <td>8.170</td>
      </tr>
      <tr>
          <td>Beef</td>
          <td>lbs</td>
          <td>294.547</td>
          <td>1854.783</td>
          <td>217.486</td>
          <td>1723.387</td>
          <td>208.457</td>
      </tr>
      <tr>
          <td>Chicken</td>
          <td>lbs</td>
          <td>149.656</td>
          <td>2419.945</td>
          <td>448.162</td>
          <td>1894.356</td>
          <td>227.083</td>
      </tr>
      <tr>
          <td>Mutton</td>
          <td>lbs</td>
          <td>248.546</td>
          <td>2004.345</td>
          <td>398.494</td>
          <td>1783.283</td>
          <td>71.114</td>
      </tr>
      </tbody>
  </table>

  <table id=\"veg-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>Tomatoes</td>
          <td>lbs</td>
          <td>0.000</td>
          <td>237.516</td>
          <td>7.324</td>
          <td>215.824</td>
          <td>14.368</td>
      </tr>
      <tr>
          <td>Onions</td>
          <td>lbs</td>
          <td>10.349</td>
          <td>482.862</td>
          <td>24.169</td>
          <td>423.451</td>
          <td>45.591</td>
      </tr>
      <tr>
          <td>Potatoes</td>
          <td>lbs</td>
          <td>50.000</td>
          <td>1786.000</td>
          <td>110.000</td>
          <td>1706.000</td>
          <td>20.000</td>
      </tr>
      <tr>
          <td>Zucchini</td>
          <td>lbs</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
      </tr>
      </tbody>
  </table>

  <table id=\"frt-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>Apples</td>
          <td>lbs</td>
          <td>0.000</td>
          <td>1106.222</td>
          <td>63.215</td>
          <td>981.841</td>
          <td>61.166</td>
      </tr>
      <tr>
          <td>Watermelons</td>
          <td>lbs</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
          <td>0.000</td>
      </tr>
      <tr>
          <td>Oranges</td>
          <td>lbs</td>
          <td>16.384</td>
          <td>768.512</td>
          <td>24.256</td>
          <td>697.247</td>
          <td>63.393</td>
      </tr>
      <tr>
          <td>Bananas</td>
          <td>lbs</td>
          <td>55.837</td>
          <td>318.593</td>
          <td>0.000</td>
          <td>337.128</td>
          <td>37.302</td>
      </tr>
      </tbody>
  </table>
";
fwrite($myfile, $txt);
fclose($myfile);
header('Location: index.php');
?>
