<?php
$dir = 'rpt/';
$files1 = scandir($dir);
$i = count($files1)-1;
  $myfile = fopen("rpt/$i.html", "w");

  $desc_m_1 = $_POST['desc_m_1'];
  $uom_m_1 = $_POST['uom_m_1'];
  $open_m_1 = $_POST['open_m_1'];
  $purchases_m_1 = $_POST['purchases_m_1'];
  $close_m_1 = $_POST['close_m_1'];
  $usage_m_1 = $_POST['usage_m_1'];
  $waste_m_1 = round($open_m_1 + $purchases_m_1 - $close_m_1 - $usage_m_1, 3);

  $desc_m_2 = $_POST['desc_m_2'];
  $uom_m_2 = $_POST['uom_m_2'];
  $open_m_2 = $_POST['open_m_2'];
  $purchases_m_2 = $_POST['purchases_m_2'];
  $close_m_2 = $_POST['close_m_2'];
  $usage_m_2 = $_POST['usage_m_2'];
  $waste_m_2 = round($open_m_2 + $purchases_m_2 - $close_m_2 - $usage_m_2, 3);

  $desc_m_3 = $_POST['desc_m_3'];
  $uom_m_3 = $_POST['uom_m_3'];
  $open_m_3 = $_POST['open_m_3'];
  $purchases_m_3 = $_POST['purchases_m_3'];
  $close_m_3 = $_POST['close_m_3'];
  $usage_m_3 = $_POST['usage_m_3'];
  $waste_m_3 = round($open_m_3 + $purchases_m_3 - $close_m_3 - $usage_m_3, 3);

  $desc_m_4 = $_POST['desc_m_4'];
  $uom_m_4 = $_POST['uom_m_4'];
  $open_m_4 = $_POST['open_m_4'];
  $purchases_m_4 = $_POST['purchases_m_4'];
  $close_m_4 = $_POST['close_m_4'];
  $usage_m_4 = $_POST['usage_m_4'];
  $waste_m_4 = round($open_m_4 + $purchases_m_4 - $close_m_4 - $usage_m_4, 3);

  $desc_v_1 = $_POST['desc_v_1'];
  $uom_v_1 = $_POST['uom_v_1'];
  $open_v_1 = $_POST['open_v_1'];
  $purchases_v_1 = $_POST['purchases_v_1'];
  $close_v_1 = $_POST['close_v_1'];
  $usage_v_1 = $_POST['usage_v_1'];
  $waste_v_1 = round($open_v_1 + $purchases_v_1 - $close_v_1 - $usage_v_1, 3);

  $desc_v_2 = $_POST['desc_v_2'];
  $uom_v_2 = $_POST['uom_v_2'];
  $open_v_2 = $_POST['open_v_2'];
  $purchases_v_2 = $_POST['purchases_v_2'];
  $close_v_2 = $_POST['close_v_2'];
  $usage_v_2 = $_POST['usage_v_2'];
  $waste_v_2 = round($open_v_2 + $purchases_v_2 - $close_v_2 - $usage_v_2, 3);

  $desc_v_3 = $_POST['desc_v_3'];
  $uom_v_3 = $_POST['uom_v_3'];
  $open_v_3 = $_POST['open_v_3'];
  $purchases_v_3 = $_POST['purchases_v_3'];
  $close_v_3 = $_POST['close_v_3'];
  $usage_v_3 = $_POST['usage_v_3'];
  $waste_v_3 = round($open_v_3 + $purchases_v_3 - $close_v_3 - $usage_v_3, 3);

  $desc_v_4 = $_POST['desc_v_4'];
  $uom_v_4 = $_POST['uom_v_4'];
  $open_v_4 = $_POST['open_v_4'];
  $purchases_v_4 = $_POST['purchases_v_4'];
  $close_v_4 = $_POST['close_v_4'];
  $usage_v_4 = $_POST['usage_v_4'];
  $waste_v_4 = round($open_v_4 + $purchases_v_4 - $close_v_4 - $usage_v_4, 3);

  $desc_f_1 = $_POST['desc_f_1'];
  $uom_f_1 = $_POST['uom_f_1'];
  $open_f_1 = $_POST['open_f_1'];
  $purchases_f_1 = $_POST['purchases_f_1'];
  $close_f_1 = $_POST['close_f_1'];
  $usage_f_1 = $_POST['usage_f_1'];
  $waste_f_1 = round($open_f_1 + $purchases_f_1 - $close_f_1 - $usage_f_1, 3);

  $desc_f_2 = $_POST['desc_f_2'];
  $uom_f_2 = $_POST['uom_f_2'];
  $open_f_2 = $_POST['open_f_2'];
  $purchases_f_2 = $_POST['purchases_f_2'];
  $close_f_2 = $_POST['close_f_2'];
  $usage_f_2 = $_POST['usage_f_2'];
  $waste_f_2 = round($open_f_2 + $purchases_f_2 - $close_f_2 - $usage_f_2, 3);

  $desc_f_3 = $_POST['desc_f_3'];
  $uom_f_3 = $_POST['uom_f_3'];
  $open_f_3 = $_POST['open_f_3'];
  $purchases_f_3 = $_POST['purchases_f_3'];
  $close_f_3 = $_POST['close_f_3'];
  $usage_f_3 = $_POST['usage_f_3'];
  $waste_f_3 = round($open_f_3 + $purchases_f_3 - $close_f_3 - $usage_f_3, 3);

  $desc_f_4 = $_POST['desc_f_4'];
  $uom_f_4 = $_POST['uom_f_4'];
  $open_f_4 = $_POST['open_f_4'];
  $purchases_f_4 = $_POST['purchases_f_4'];
  $close_f_4 = $_POST['close_f_4'];
  $usage_f_4 = $_POST['usage_f_4'];
  $waste_f_4 = round($open_f_4 + $purchases_f_4 - $close_f_4 - $usage_f_4, 3);

  $txt = "<table id=\"meat-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>$desc_m_1</td>
          <td>$uom_m_1</td>
          <td>$open_m_1</td>
          <td>$purchases_m_1</td>
          <td>$close_m_1</td>
          <td>$usage_m_1</td>
          <td>$waste_m_1</td>
      </tr>
      <tr>
          <td>$desc_m_2</td>
          <td>$uom_m_2</td>
          <td>$open_m_2</td>
          <td>$purchases_m_2</td>
          <td>$close_m_2</td>
          <td>$usage_m_2</td>
          <td>$waste_m_2</td>
      </tr>
      <tr>
          <td>$desc_m_3</td>
          <td>$uom_m_3</td>
          <td>$open_m_3</td>
          <td>$purchases_m_3</td>
          <td>$close_m_3</td>
          <td>$usage_m_3</td>
          <td>$waste_m_3</td>
      </tr>
      <tr>
          <td>$desc_m_4</td>
          <td>$uom_m_4</td>
          <td>$open_m_4</td>
          <td>$purchases_m_4</td>
          <td>$close_m_4</td>
          <td>$usage_m_4</td>
          <td>$waste_m_4</td>
      </tr>
      </tbody>
  </table>

  <table id=\"veg-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>$desc_v_1</td>
          <td>$uom_v_1</td>
          <td>$open_v_1</td>
          <td>$purchases_v_1</td>
          <td>$close_v_1</td>
          <td>$usage_v_1</td>
          <td>$waste_v_1</td>
      </tr>
      <tr>
          <td>$desc_v_2</td>
          <td>$uom_v_2</td>
          <td>$open_v_2</td>
          <td>$purchases_v_2</td>
          <td>$close_v_2</td>
          <td>$usage_v_2</td>
          <td>$waste_v_2</td>
      </tr>
      <tr>
          <td>$desc_v_3</td>
          <td>$uom_v_3</td>
          <td>$open_v_3</td>
          <td>$purchases_v_3</td>
          <td>$close_v_3</td>
          <td>$usage_v_3</td>
          <td>$waste_v_3</td>
      </tr>
      <tr>
          <td>$desc_v_4</td>
          <td>$uom_v_4</td>
          <td>$open_v_4</td>
          <td>$purchases_v_4</td>
          <td>$close_v_4</td>
          <td>$usage_v_4</td>
          <td>$waste_v_4</td>
      </tr>
      </tbody>
  </table>

  <table id=\"frt-table-$i\" style=\"display: none;\">
      <thead>
      <tr>
          <th>Description</th>
          <th>UoM</th>
          <th>Opening Inventory</th>
          <th>Period Purchases</th>
          <th>Ending Inventory</th>
          <th>Actual Usage</th>
          <th>Calculated Waste</th>
      </tr>
      </thead>
      <tbody>
      <tr>
          <td>$desc_f_1</td>
          <td>$uom_f_1</td>
          <td>$open_f_1</td>
          <td>$purchases_f_1</td>
          <td>$close_f_1</td>
          <td>$usage_f_1</td>
          <td>$waste_f_1</td>
      </tr>
      <tr>
          <td>$desc_f_2</td>
          <td>$uom_f_2</td>
          <td>$open_f_2</td>
          <td>$purchases_f_2</td>
          <td>$close_f_2</td>
          <td>$usage_f_2</td>
          <td>$waste_f_2</td>
      </tr>
      <tr>
          <td>$desc_f_3</td>
          <td>$uom_f_3</td>
          <td>$open_f_3</td>
          <td>$purchases_f_3</td>
          <td>$close_f_3</td>
          <td>$usage_f_3</td>
          <td>$waste_f_3</td>
      </tr>
      <tr>
          <td>$desc_f_4</td>
          <td>$uom_f_4</td>
          <td>$open_f_4</td>
          <td>$purchases_f_4</td>
          <td>$close_f_4</td>
          <td>$usage_f_4</td>
          <td>$waste_f_4</td>
      </tr>
      </tbody>
  </table>
";
fwrite($myfile, $txt);
fclose($myfile);
header('Location: index.php');
?>
