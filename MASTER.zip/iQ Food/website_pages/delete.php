<?php
$dir = 'rpt/';
$files1 = scandir($dir);
$i = count($files1)-2;
$a = unlink("rpt/$i.html");
header('Location: index.php');
?>
