<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">

    <link rel="stylesheet" href="libs/pure-min.css">

    <link rel="stylesheet" href="libs/grids-responsive-min.css">

    <title>iQ Foods Reports</title>

    <style>
        * {
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            overflow: hidden;
        }

        .navbar {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background: #e74c3c;
            border-bottom: 5px solid #c0392b;
            height: 50px;
            white-space: nowrap;
            overflow-x: auto;
            overflow-y: hidden;
            padding: 0 10px;
        }

        .navbar h1 {
            font-size: 20px;
            color: #fff;
        }

        .menu {
            padding: 0;
            list-style: none;
            color: #66615B;
            font-weight: bold;
            font-family: sans-serif;
        }

        .menu li {
            vertical-align: top;
        }

        .menu li a {
            text-decoration: none;
            color: #66615B;
            font-weight: normal;
            font-family: sans-serif;
            padding: 10px 0;
            line-height: 25px;
        }

        .menu li a:hover {
            font-style: italic;
        }

        #panel {
            background: #f4f3ef;
            padding: 10px;
            height: 100%;
        }

        #wrapper {
            overflow: hidden;
            height: 100%;
            background: rgba(193, 193, 193, 1);
        }

        #output {
            width: 100%;
            height: 100%;
            background: rgba(193, 193, 193, 1);
        }
    </style>
    <script src="libs/include-html.js"></script>
</head>
<body>

<div class="pure-g" style="height: 100%;">
    <div id="panel" class="pure-u-1 pure-u-md-1-6">
        <ul class="menu">
            iQ Foods Reports
            <li>&nbsp;</li>
            <li><a href="index.php">Refresh</a></li>
            <li><a href="create.php">Add (Dev use only)</a></li>
            <li><a href="post_test.html">AddPOST (Dev use only)</a></li>
            <li><a href="delete.php">Delete</a></li>
            <li>&nbsp;</li>
            <?php
            $dir = 'rpt/';
            $files1 = scandir($dir);
            for ($i=count($files1)-2; $i > 0 ; $i--) {
              echo("<li><a href=\"#");
              echo($i);
              echo("\">Week ");
              echo($i);
              echo("</a></li>");
            }
            ?>
        </ul>
    </div>
    <div id="wrapper" class="pure-u-1 pure-u-md-5-6">
        <iframe id="output"></iframe>
    </div>
</div>

<?php
$dir = 'rpt/';
$files1 = scandir($dir);
for ($i=count($files1)-2; $i > 0 ; $i--) {
  echo("<div include-html=\"rpt/");
  echo($i);
  echo(".html\"></div>");
}
?>

<script>
includeHTML();
</script>

<script src="libs/jspdf.debug.js"></script>

<script src="libs/jspdf.plugin.autotable.js"></script>

<script src="autotable-script.js"></script>

<script>
    window.onhashchange = function () {
        update();
    };

    function update(shouldDownload) {
        var funcStr = window.location.hash.replace(/#/g, '');
        var doc = pdf.wk(funcStr);

        doc.setProperties({
            title: 'report ' + funcStr,
            subject: 'report ' + funcStr
        });

        if (shouldDownload) {
            doc.save('table.pdf');
        } else {
            document.getElementById("output").src = doc.output('datauristring');
        }
    }

    update();
</script>
</body>
</html>
