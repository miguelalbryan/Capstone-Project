<?php
// Used to Login & Register users
ob_start();
session_start();

//---------------------------------
 //Error Array

	$errors = array();
	$fname = "";
	$lname = "";
	$userName = "";

// To Connect To The Server - Used MySQLi

$db_connect = mysqli_connect('localhost','root','','comp3078');

If($db_connect){
	echo "Success";
	
}

else  {
	echo "Failed";
}

if(isset($_POST['login'])){

$email_or_userName = mysqli_real_escape_string($db_connect,$_POST['username']);
$pass =  mysqli_real_escape_string($db_connect,$_POST['password']);


 // checks with userName or Email
$loginQuery = "SELECT * FROM user_t WHERE user_Email='$email_or_userName' OR user_userName = '$email_or_userName'";
$result = mysqli_query($db_connect,$loginQuery); // Inserts Query into The Database and returns mysqli_result Object.
$userRow = mysqli_fetch_array($result, MYSQLI_BOTH); // Stores the object into an array;
$password = password_verify($pass,$userRow["user_Password"]); // Verifies the password

if(($userRow["user_Email"]==$email_or_userName || $userRow["user_userName"]==$email_or_userName) && $password == true ){
	//$_SESSION['user_ID'] = $userRow["user_ID"]; // Sets user_ID session Variable to ID of the logged in User.
	$_SESSION['user'] = $userRow["user_userName"];	
	header("Location:../../../dashboard.php"); 
}
else if(($userRow["user_Email"]==$email_or_userName || $userRow["user_userName"]==$email_or_userName) && $password == false ){	
	header("Location:../../login.php?err=1"); 
}
else{
header("Location:../../login.php?err=2");	
}
}



?>
