 <div class="row text-center ">
 	<div class="col-lg-3 col-md-3">
 		<div class="jumbotron"><p>AD here</p></div>
 	 </div>

 	 <div class="col-lg-3 offset-lg-1">
  	<div class="jumbotron"> AD HERE</div>
  </div>