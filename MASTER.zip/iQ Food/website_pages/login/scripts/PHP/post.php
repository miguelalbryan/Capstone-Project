<?php
// User must be logged In Code
?>
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>salesPoint - Welcome</title>
  <meta name="description" content="This is the salesPoint. The perfect portal for you to sell your items.">
  <meta name="author" content="Yash Thanki">
  <link rel="stylesheet" href="../../css/bootstrap.css ">
  <script src="../../js/bootstrap.min.js" type="text/javascript"></script>
  <link rel="stylesheet" type="text/css" href="../../css/custom_css/style.css">
  <script defer src="https://use.fontawesome.com/releases/v5.0.4/js/all.js"></script>


  <!--[if lt IE 9]>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.js"></script>
  <![endif]-->`
</head>

<body>
  <nav class="navbar fixed-top navbar-expand-sm bg-light">
    <div class="container">
      <div class="navbar-brand">
       HOME
      </div>
      <div class="navbar-nav">
        <a class="nav-item nav-link active font-black" href="#">Home</a>
        <a class="nav-item nav-link active font-black" href="#">About</a>
        <a class="nav-item nav-link active font-black" href="#">Contact</a>
        <div>
        <a href="login.php" class="btn btn-md font-black bg-gray font-black">Login</a>
        <a href="register.php" class="btn btn-md bg-dark font-white">Register</a>
      </div>
      
      </div>
      
    </div>
  </nav>

  <!--  -->
  <br>
  <br>
  <br>


<div class="container">
  <h2 class="page-header">Post An AD!</h2>
  <br>
 <div class="row text-center ">
 	
  <div class="col-md-6 offset-md-3 ">
    <form action="scripts/PHP/DB_Connect.php" method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <input class="form-control" placeholder="Title" type="text" name="item_Title">
      </div>

    <div class="input-group mb-3">
    <div class="input-group-prepend">
    <span class="input-group-text">$</span>
    </div>
    <input type="text" class="form-control" placeholder= "Price" aria-label="Amount (to the nearest dollar)">
	</div>

       <div class="form-group">
        <select class="form-control">
        	<option>Select Category</option>
        	<option value="Electronics">Electronics</option>
        	<option value="Real Estate">Real Estate</option>
        	<option value="Automobiles">Automobiles</option>
        	<option value="Rentals">Rentals</option>
        	<option value="Other">Other</option>
        </select>
      </div>

       <div class="form-group">
        <input class="form-control" placeholder="Location" type="text" name="item_Title">
      </div>
 		
  		<div class="form-group">      	
    	<input id="my-file-selector" multiple="multiple" class="form-control" type="file">
    	</div>
      	

      <div class="form-group">
        <textarea class="form-control" placeholder="Description" rows="5" type="text" name="item_Title"></textarea>
      </div>
      <small id="emailHelp" class="form-text text-muted">By Clicking Post, you agree to our advertisement policy.</small>
      <button type="submit" name="post" class="col-lg-6 btn btn-primary">Post</button>
      </form>
      </div> 
  </div>
  
 </div>
 <button type="button" class="btn btn-default btn-lg">
  <span class="glyphicon glyphicon-star" aria-hidden="true"></span> Star
</button>

  	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</body>
</html>