<?php
		session_start();
		ob_start();
		unset($_SESSION['user']);
		session_unset();
		session_destroy();
		
				if (!isset($_SESSION["user"]))
			header("Location:../../login.php");
?>

