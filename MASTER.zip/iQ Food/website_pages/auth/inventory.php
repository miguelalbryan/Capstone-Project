<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>iQ Foods Inventory</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="../assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/themify-icons.css" rel="stylesheet">



</head>
<body>
<?php
session_start();

		//Do a check auth over here Check whether a session exists.
include "login/scripts/PHP/checkAuth.php";



//Have to check if the database connection still ecists
$db_connect = mysqli_connect('localhost','root','','comp3078');



?>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="" class="simple-text">
                    IQ Foods
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>


                  <li class="active">
                    <a href="inventory.php">
                        <i class="ti-view-list-alt"></i>
                        <p>Inventory</p>
                    </a>
                </li>
                <li>
                    <a href="weeklylog.php">
                        <i class="ti-pencil"></i>
                        <p>Weekly Log</p>
                    </a>
                </li>
                <li>
                    <a href="report.php">
                        <i class="ti-receipt"></i>
                        <p>Report</p>
                    </a>
                </li>

				      <li>
                    <a href="login/scripts/PHP/logout.php">
                        <i class="ti-power-off"></i>
                        <p>Log Out</p>
                    </a>
                </li>



            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Inventory</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p><?php echo $_SESSION['user'];?></p> <!-- Username -->
                            </a>
                        </li>

                    </ul>

                </div>
            </div>
        </nav>
        <h1 align="center">iQ Food Inventory </h1>









		<!-- Test Example -->

		<div class="content">
            <div class="container-fluid">
                <div class="row">

                    <div class="jquery-script-clear"></div>
                </div>
            </div>
            <div class="container">
                <div class="table-responsive">
										<span><button><a href="editinventory.php"> Edit Inventory </a></button></span>

					<!-- This is where the table starts-->
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Categories </th>
                            <th>Product</th>
                            <th>Supplier Name</th>
                            <th>Product ID</th>
                            <th>Product Description</th>
                            <th>Purchasing Price</th>
                            <th>Selling Price</th>
                            <th>Quantity</th>
                        </tr>
                        </thead>
                        <tbody>

						<!-- Where you can start popoulating the table -->



                    <?php

					$db_connect = new mysqli('localhost','root','','comp3078');
					$food_group_query = $db_connect->query("SELECT `food_groupName` FROM `food_group`;");
					$food_groupID_query = $db_connect->query("SELECT `food_groupID` FROM `food_group`;");

					//Array that holds name and ID values
					$food_groupID_array = Array();
					$food_group_array = Array();

					while($food_group_result = $food_group_query->fetch_assoc())
					{
						$food_group_array[] = $food_group_result['food_groupName'];
					}

					while($food_groupID_result = $food_groupID_query -> fetch_assoc())
					{
						$food_groupID_array[] = $food_groupID_result['food_groupID'];
					}


					//Combines two array into associative array
					$food_arr = array_combine($food_groupID_array, $food_group_array);



					if($food_arr)
					{
						foreach($food_arr as $id=>$name)
						{
						echo "<tr>";
							echo "<td>".$name."</td>"; //First column of table Name: First Column First Row

							//Dropdown to see the sub-category
							//SELECT * FROM product_inventory WHERE food_groupID_FK =" $id ";"

												$db_connect = new mysqli('localhost','root','','comp3078');

												$food_product_query = $db_connect->query("SELECT `productName` FROM `product_inventory` WHERE `food_groupID_FK` = $id;");

												//Array that holds the product names
												$food_product_array = Array();

													echo "<td id=\"\">&nbsp;<div class=\"btn-group\">
													<form>
													<select id=\"$name\"  name=\"product\" onchange=\"showProduct(this.value,this.id)\">";
														echo"<option value=\"\">Choose Product</option>";
														while($food_product_result = $food_product_query->fetch_assoc())
														{


															echo "<option value=".$food_product_result['productName'].">".$food_product_result['productName']."</option>";
															$food_product_array[] = $food_product_result['productName'];

															//Products into the drop down inventory Second Column First Row
														}
														print_r($food_product_array);

													echo  "</select></form></div></td>";
													echo "<td></td>";
													echo "<td></td>";
													echo "<td></td>";
													echo "<td></td>";
													echo "<td></td>";
													echo "<td></td>";




													echo "<tr id=\"txtProduct$name\">";


                          echo "</tr>";


						echo "</tr>";




						}





					}











					?>

                        </tbody>
                    </table>




            </div>
            <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
            <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script src="bootstable.js"></script>

                <script>
                    $('#makeEditable').SetEditable({ $addButton: $('#but_add')});
                </script>

			</div>
        </div>
    </div>



        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.iqfoodco.com/">
                                IQ Food Store
                            </a>
                        </li>
                        <li>
                            <a href="">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <a href="http://www.iqfoodco.com/"> IQ Foods</a>
                </div>
            </div>
        </footer>

    </div>
</div>



</body>


    <!--   Core JS Files   -->
    <script src="../assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="../assets/js/paper-dashboard.js"></script>

    <script src="../assets/js/dropdown.js"></script>



<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-menu-alt',
            	message: "Welcome to <b>Inventory Page</b> - (Notification of past activites will go here)."

            },{
                type: 'success',
                timer: 40
            });

    	});
	</script>

<script>
    $('#makeEditable').SetEditable({ $addButton: $('#but_add')});
</script>





<script>
function showProduct(str,foodgroupname) {


    if (str == "") {
        document.getElementById("txtProduct"+foodgroupname).innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtProduct"+foodgroupname).innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","getproduct.php?q="+str,true);
        xmlhttp.send();
    }
}
</script>
</html>
