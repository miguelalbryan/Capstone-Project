<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>iQ Foods Inventory</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="../assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>
<?php
session_start();

		//Do a check auth over here Check whether a session exists.
include "login/scripts/PHP/checkAuth.php";

?>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="" class="simple-text">
                    IQ Foods
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>


                  <li class="active">
                    <a href="inventory.php">
                        <i class="ti-view-list-alt"></i>
                        <p>Inventory</p>
                    </a>
                </li>
                <li>
                    <a href="weeklylog.php">
                        <i class="ti-pencil"></i>
                        <p>Weekly Log</p>
                    </a>
                </li>
                <li>
                    <a href="report.php">
                        <i class="ti-receipt"></i>
                        <p>Report</p>
                    </a>
                </li>

				      <li>
                    <a href="login/scripts/PHP/logout.php">
                        <i class="ti-power-off"></i>
                        <p>Log Out</p>
                    </a>
                </li>



            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Inventory</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p><?php echo $_SESSION['user'];?></p> <!-- Username -->
                            </a>
                        </li>

                    </ul>

                </div>
            </div>
        </nav>
        <h1 align="center">iQ Food Inventory </h1>



        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="jquery-script-ads"><script type="text/javascript"><!--
                    google_ad_client = "ca-pub-2783044520727903";
                    /* jQuery_demo */
                    google_ad_slot = "2780937993";
                    google_ad_width = 728;
                    google_ad_height = 90;
                    //-->
                    </script>
                        <script type="text/javascript"
                                src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        </script></div>
                    <div class="jquery-script-clear"></div>
                </div>
            </div>
            <div class="container">
                <div class="table-responsive">
									<span><button id="but_add"> Add New Row</button></span>
									<span><button><a href="inventory.php"> Back</button></a></span>
                    <table class="table table-bordered" id="makeEditable">
                        <thead>
                        <tr>
                            <th>Categories </th>
                            <th>Product</th>
                            <th>Supplier Name</th>
                            <th>Product ID</th>
                            <th>Product Description</th>
                            <th>Purchasing Price</th>
                            <th>Selling Price</th>
                            <th>Quantity</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>Meat</td>
                            <td id="asd">&nbsp;<div class="btn-group">
                                <select id="meat_selections" onchange="meat_selections_edit()">
                                    <option value="Pork">Pork</option>
                                    <option value="Beef">Beef</option>
                                    <option value="Chicken">Chicken</option>
                                    <option value="Mutton">Mutton</option>
                                </select>
                            </div></td>
                            <td id="meat_sup_num" name="meat_sup_num">Ontario's Pork Industry</td>
                            <td id="meat_st_num">Stock-Number-101</td>
                            <td id="meat_st_item">Half ham Typical slice of ham Ham is pork from a leg cut that has been preserved by wet or dry curing, with or without smoking.[1] As a processed meat, the term "ham" includes both whole cuts of meat and ones that have been mechanically formed.</td>
                            <td id="meat_pp_item">$4</td>
                            <td id="meat_sp_item">$10</td>
                            <td id="meat_quantity">179</td>
                        </tr>
                        <tr>
                            <td>Vegetables</td>
                            <td id="asd"><div class="btn-group">
                                <select id="veg_selections" onchange="veg_selections_edit()">
                                    <option value="Tomatoes">Tomatoes</option>
                                    <option value="Onions">Onions</option>
                                    <option value="Potatoes">Potatoes</option>
                                    <option value="Zucchini">Zucchini</option>
                                </select>
                            </div></td>
                            <td id="veg_sup_num" name="meat_sup_num">Fresh Tomato</td>
                            <td id="veg_st_num">Stock Number - 104</td>
                            <td id="veg_st_item">There are a wide range of processed tomato products on the market, from canned tomatoes, juice, soup, sauce, paste, ketchup, pulp to puree. Color is particularly important for processed tomatoes and fruit need to be of a uniform.</td>
                            <td id="veg_pp_item">$4</td>
                            <td id="veg_sp_item">$11</td>
                            <td id="veg_quantity">142</td>
                        </tr>
                        <tr>
                            <td>Fruits</td>
                            <td id="asd"><div class="btn-group">
                                <select id="fruit_selections" onchange="fruit_selections_edit()">
                                    <option value="Apples">Apples</option>
                                    <option value="Watermelon">Watermelon</option>
                                    <option value="Oranges">Oranges</option>
                                    <option value="Bananas">Bananas</option>
                                </select>
                            </div></td>
                            <td id="fruit_sup_num" name="meat_sup_num">Zhangjian Apples</td>
                            <td id="fruit_st_num">Stock Number - 107</td>
                            <td id="fruit_st_item">Tufahije is a Bosnian dessert made of walnut-stuffed apples stewed in water with sugar. This is a dynamic list and may never be able to satisfy particular standard.</td>
                            <td id="fruit_pp_item">$3/td>
                            <td id="fruit_sp_item">$12</td>
                            <td id="fruit_quantity">$756</td>
                        </tr>

                        </tbody>
                    </table>
            </div>
            <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
            <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script src="bootstable.js"></script>

                <script>
                    $('#makeEditable').SetEditable({ $addButton: $('#but_add')});
                </script>

        </div>
            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.iqfoodco.com/">
                                IQ Food Store
                            </a>
                        </li>
                        <li>
                            <a href="">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <a href="http://www.iqfoodco.com/"> IQ Foods</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>


    <!--   Core JS Files   -->
    <script src="../assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="../assets/js/paper-dashboard.js"></script>

    <script src="../assets/js/dropdown.js"></script>



<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-menu-alt',
            	message: "Welcome to <b>Inventory Page</b> - (Notification of past activites will go here)."

            },{
                type: 'success',
                timer: 40
            });

    	});
	</script>

<script>
    $('#makeEditable').SetEditable({ $addButton: $('#but_add')});
</script>






</html>
