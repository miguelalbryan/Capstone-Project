<tr>
	<td>Meat0</td>
	<td id="">&nbsp;<div class="btn-group">
													<form>
													<select id="thisdropdown" name="product" onchange="showProduct(this.value)">
														<option value="">Choose Product</option>
														<option value="Pork&quot;">Pork</option>
														<option value="Beef&quot;">Beef</option>
														<option value="Chicken&quot;">Chicken</option>
														</select>
													</form>
</div>

</td>

<td>
Supplier Name
</td>



</tr>

<tr>
	<td>Vegetable1</td>
	<td id="">&nbsp;<div class="btn-group">
													<form>
													<select id="thisdropdown" name="product" onchange="showProduct(this.value)">
														<option value="">Choose Product</option>
														<option value="Pork&quot;">Tomato</option>
														<option value="Beef&quot;">Onion</option>
														<option value="Chicken&quot;">Potato</option>
														</select>
													</form>
</div>

</td>

<td>
Supplier Name
</td>
<td>
Product Description
</td>

</tr>
