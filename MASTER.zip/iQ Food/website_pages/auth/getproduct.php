<!DOCTYPE html>
<html>
<head>

<body>

<?php
$q = strval($_GET['q']);

$db_connect = new mysqli('localhost','root','','comp3078');
$food_productrow_query = $db_connect->query("SELECT * FROM product_inventory WHERE productName = '$q';");


while($row = $food_productrow_query->fetch_assoc())
{
	echo "<td></td>";
	echo "<td></td>";
	echo "<td>".$row["supplierName"]."</td>";
	echo "<td>Stock Number - ".$row["productID"]."</td>";
  echo "<td>".$row["productDescription"]."</td>";
	echo "<td>$".$row["purchasingPrice"]."</td>";
	echo "<td>$".$row["sellingPrice"]."</td>";
  echo "<td>".$row["quantity"]."</td>";


}



mysqli_close($db_connect);
?>


</body>
</html>
