<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>iQ Foods Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="../assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>
<?php
session_start();

		//Do a check auth over here Check whether a session exists.
include "login/scripts/PHP/checkAuth.php";

?>
<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="" class="simple-text">
                    IQ Foods
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li>
                    <a href="inventory.php">
                        <i class="ti-view-list-alt"></i>
                        <p>Inventory</p>
                    </a>
                </li>
                <li>
                    <a href="weeklylog.php">
                        <i class="ti-pencil"></i>
                        <p>Weekly Log</p>
                    </a>
                </li>
                <li>
                    <a href="report.php">
                        <i class="ti-receipt"></i>
                        <p>Report</p>
                    </a>
                </li>

				<li>
                    <a href="login/scripts/PHP/logout.php">
                        <i class="ti-power-off"></i>
                        <p>Log Out</p>
                    </a>
                </li>



            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p><?php echo $_SESSION['user'];?></p> <!-- Username -->
                            </a>
                        </li>

                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
					<div class="container" style="width: 30%;">
							<h2 align="center">Welcome, <?php echo $_SESSION['user'];?> </h2>
							<div id="myCarousel" class="carousel slide" data-ride="carousel">
									<!-- Indicators -->
									<ol class="carousel-indicators">
											<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
											<li data-target="#myCarousel" data-slide-to="1"></li>
											<li data-target="#myCarousel" data-slide-to="2"></li>
									</ol>

									<!-- Wrapper for slides -->
									<div class="carousel-inner">

											<div class="item active">
													<img src="iqpic1.jpeg" alt="Los Angeles" style="width:100%;">
													<div class="carousel-caption">
															<h3>HOW WE WORK FOR OUR TEAM</h3>
															<p>In every aspect of our business,
																	we look to lead and make decisions that will help shape the future of the
																	hospitality industry for years to come.<a href="https://medium.com/@iqfoodco/how-we-work-for-our-team-db1ec2d0ef2b"> Learn More</a></p>
													</div>
											</div>

											<div class="item">
													<img src="iqpic2.jpeg" alt="Chicago" style="width:100%;">
													<div class="carousel-caption">
															<h3>CHILI ROASTED KABOCHA SQUASH W/ LIME CREMA + JALAPENOS</h3>
															<p>This is a great recipe for batch cooking and works w/ any kind of squash,
																	so break down a few kabochas,
																	acorns or buttercups next Sunday
																	and enjoy a next level lunch game all week!<a href="https://medium.com/@iqfoodco/chili-roasted-kabocha-squash-w-lime-crema-jalapenos-f37729304bae"> Learn More</a></p>
													</div>
											</div>

											<div class="item">
													<img src="iqpic3.jpeg" alt="New York" style="width:100%;">
													<div class="carousel-caption">
															<h3 style="color: black;">WE’RE GOING CASHLESS</h3>
															<p style="color: black;"> Why we’re saying goodbye to cash across all of our restaurants.
																	<a href="https://medium.com/@iqfoodco/were-going-cashless-7d37f0cd68ee"> Learn More</a></p>
													</div>
											</div>

									</div>

									<!-- Left and right controls -->
									<a class="left carousel-control" href="#myCarousel" data-slide="prev">
											<span class="ti-control-backward"></span>
											<span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#myCarousel" data-slide="next">
											<span class="ti-control-forward"></span>
											<span class="sr-only">Next</span>
									</a>

							</div>
							<br>
					</div>
            <div class="container-fluid">
                <div class="row">

									<hr>

									<h2 align="center">Storage</h2>
									<br>


										<?php

										$db_connect = new mysqli('localhost','root','','comp3078');
										$food_group_query = $db_connect->query("SELECT `food_groupName` FROM `food_group`;");
										$food_groupID_query = $db_connect->query("SELECT `food_groupID` FROM `food_group`;");

										//Array that holds name and ID values
										$food_groupID_array = Array();
										$food_group_array = Array();

										while($food_group_result = $food_group_query->fetch_assoc())
										{
										$food_group_array[] = $food_group_result['food_groupName'];
										}

										while($food_groupID_result = $food_groupID_query -> fetch_assoc())
										{
										$food_groupID_array[] = $food_groupID_result['food_groupID'];
										}


										//Combines two array into associative array
										$food_arr = array_combine($food_groupID_array, $food_group_array);



										if($food_arr)
										{
										foreach($food_arr as $id=>$name)
										{

											$db_connect = new mysqli('localhost','root','','comp3078');

											$food_quantity_query = $db_connect->query("SELECT SUM(quantity) AS GroupQuantity FROM product_inventory WHERE food_groupID_FK = $id");


												while($food_product_result = $food_quantity_query->fetch_assoc()){

												$foodquant = $food_product_result['GroupQuantity'];

												//Products into the drop down inventory Second Column First Row



									echo "	<div class=\"col-lg-3 col-sm-6\" style=\"width: 50%;\">
																				<div class=\"card\">
																						<div class=\"content\">
																							<div class=\"row\">
																								<div class=\"col-xs-5\">
																									<div class=\"icon-big icon-warning text-center\">

																									</div>
																								</div>
																								<div class=\"col-xs-7\">
																								<div class=\"numbers\">
																		<p>Overall 	$name Storage</p>
																				$foodquant g
																			</div>
																				</div>
																					</div>
																							<div class=\"footer\">
																								<hr/>
																									<div class=\"stats\">

																	</div>
																			</div>
																					</div>
																							</div>

																			</div>";
																		}

										}
										}
										?>



                </div>
								<hr>

								<h2 align="center">Status</h2>
								<br>

								<div class="row">
									<?php


										$db_connect = new mysqli('localhost','root','','comp3078');

										$food_quantity_query = $db_connect->query("SELECT productName, quantity FROM product_inventory WHERE quantity<0");


											while($food_product_result = $food_quantity_query->fetch_assoc()){

											$foodquant = $food_product_result['productName'];
											$number = $food_product_result['quantity'];
											//Products into the drop down inventory Second Column First Row



								echo "	<div class=\"col-lg-3 col-sm-6\" style=\"width: 50%;\">
																			<div class=\"card\">
																					<div class=\"content\">
																						<div class=\"row\">
																							<div class=\"col-xs-5\">
																								<div class=\"icon-big icon-warning text-center\">

																								</div>
																							</div>
																							<div class=\"col-xs-7\">
																							<div class=\"numbers\">
																	<p>$foodquant</p>

																			$number g
																		</div>
																			</div>
																				</div>
																						<div class=\"footer\">
																							<hr/>
																								<div class=\"stats\">

																</div>
																		</div>
																				</div>
																						</div>

																		</div>";
																	}



									?>
								</div>

								<hr>

									<div class="col-lg-3 col-sm-6" style="width: 50%;">
											<div class="card">
													<div class="content">
															<div class="row">
																	<div class="col-xs-5">
																			<div class="icon-big icon-success text-center">
																					<i class="ti-wallet"></i>
																			</div>
																	</div>
																	<div class="col-xs-7">
																			<div class="numbers">
																					<p>Revenue</p>
																					$1,345
																			</div>
																	</div>
															</div>
															<div class="footer">
																	<hr />
																	<div class="stats">
																			<i class="ti-calendar"></i> Last day
																	</div>
															</div>
													</div>
											</div>
									</div>
								</div>

            </div>

        </div>




        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.iqfoodco.com/">
                                IQ Food Store
                            </a>
                        </li>
                        <li>
                            <a href="">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <a href="http://www.iqfoodco.com/"> IQ Foods</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="../assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-dashboard',
            	message: "Welcome to <b>The Dashboard</b> - (Notification of past activites will go here)."

            },{
                type: 'success',
                timer: 40
            });

    	});
	</script>

</html>
