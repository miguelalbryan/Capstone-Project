<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>iQ Foods Weekly Log</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="../assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="../assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="../assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="../assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>
<?php
session_start();

		//Do a check auth over here Check whether a session exists.
include "login/scripts/PHP/checkAuth.php";

?>
<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="" class="simple-text">
                    IQ Foods
                </a>
            </div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>


                  <li>
                    <a href="inventory.php">
                        <i class="ti-view-list-alt"></i>
                        <p>Inventory</p>
                    </a>
                </li>
                <li class="active">
                    <a href="weeklylog.php">
                        <i class="ti-pencil"></i>
                        <p>Weekly Log</p>
                    </a>
                </li>
                <li>
                    <a href="report.php">
                        <i class="ti-receipt"></i>
                        <p>Report</p>
                    </a>
                </li>

				      <li>
                    <a href="login/scripts/PHP/logout.php">
                        <i class="ti-power-off"></i>
                        <p>Log Out</p>
                    </a>
                </li>



            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Weekly Log</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i class="ti-user"></i>
								<p><?php echo $_SESSION['user'];?></p> <!-- Username -->
                            </a>
                        </li>

                    </ul>

                </div>
            </div>
        </nav>

        <div class="content">
            <div class="container-fluid">
                <div class="jquery-script-clear"></div>

                <div class="table-responsive" id="log_form">
									<form action="create_post.php" method="post">


                        <table id="makeEditable" class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Description</th>
                                <th>UoM</th>
                                <th>Opening Inventory</th>
                                <th>Period Purchases</th>
                                <th>Ending Inventory</th>
                                <th>Actual Usage</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td id="desc_m_1">Pork</td>
                                <td id="uom_m_1">lbs</td>
                                <td id="open_m_1">357.898</td>
                                <td id="purchases_m_1">2149.432</td>
                                <td id="close_m_1">245.194</td>
                                <td id="usage_m_1">2253.966</td>

                            </tr>
                            <tr>
                                <td id="desc_m_2">Beef</td>
                                <td id="uom_m_2">lbs</td>
                                <td id="open_m_2">294.547</td>
                                <td id="purchases_m_2">1854.783</td>
                                <td id="close_m_2">217.486</td>
                                <td id="usage_m_2">1723.387</td>

                            </tr>
                            <tr>
                                <td id="desc_m_3">Chicken</td>
                                <td id="uom_m_3">lbs</td>
                                <td id="open_m_3">149.656</td>
                                <td id="purchases_m_3">2419.945</td>
                                <td id="close_m_3">448.162</td>
                                <td id="usage_m_3">1894.356</td>

                            </tr>
                            <tr>
                                <td id="desc_m_4">Mutton</td>
                                <td id="uom_m_4">lbs</td>
                                <td id="open_m_4">248.546</td>
                                <td id="purchases_m_4">2004.345</td>
                                <td id="close_m_4">398.494</td>
                                <td id="usage_m_4">1783.283</td>

                            </tr>
                            </tbody>
                        </table>


                        <table id="makeEditable2" class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Description</th>
                                <th>UoM</th>
                                <th>Opening Inventory</th>
                                <th>Period Purchases</th>
                                <th>Ending Inventory</th>
                                <th>Actual Usage</th>


                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td id="desc_v_1">Tomatoes</td>
                                <td id="uom_v_1">lbs</td>
                                <td id="open_v_1">0.000</td>
                                <td id="purchases_v_1">237.516</td>
                                <td id="close_v_1">7.324</td>
                                <td id="usage_v_1">215.824</td>

                            </tr>
                            <tr>
                                <td id="desc_v_2">Onions</td>
                                <td id="uom_v_2">lbs</td>
                                <td id="open_v_2">10.349</td>
                                <td id="purchases_v_2">482.862</td>
                                <td id="close_v_2">24.169</td>
                                <td id="usage_v_2">423.451</td>

                            </tr>
                            <tr>
                                <td id="desc_v_3">Potatoes</td>
                                <td id="uom_v_3">lbs</td>
                                <td id="open_v_3">50.000</td>
                                <td id="purchases_v_3">1786.000</td>
                                <td id="close_v_3">110.000</td>
                                <td id="usage_v_3">1706.000</td>

                            </tr>
                            <tr>
                                <td id="desc_v_4">Zucchini</td>
                                <td id="uom_v_4">lbs</td>
                                <td id="open_v_4">0.000</td>
                                <td id="purchases_v_4">0.000</td>
                                <td id="close_v_4">0.000</td>
                                <td id="usage_v_4">0.000</td>

                            </tr>
                            </tbody>
                        </table>

                    

                        <table id="makeEditable3" class="table table-bordered">
                            <thead>
                            <tr>
                                <th>Description</th>
                                <th>UoM</th>
                                <th>Opening Inventory</th>
                                <th>Period Purchases</th>
                                <th>Ending Inventory</th>
                                <th>Actual Usage</th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td id="desc_f_1">Apples</td>
                                <td id="uom_f_1">lbs</td>
                                <td id="open_f_1">0.000</td>
                                <td id="purchases_f_1">1106.222</td>
                                <td id="close_f_1">63.215</td>
                                <td id="usage_f_1">981.841</td>

                            </tr>
                            <tr>
                                <td id="desc_f_2">Watermelons</td>
                                <td id="uom_f_2">lbs</td>
                                <td id="open_f_2">0.000</td>
                                <td id="purchases_f_2">0.000</td>
                                <td id="close_f_2">0.000</td>
                                <td id="usage_f_2">0.000</td>

                            </tr>
                            <tr>
                                <td id="desc_f_3">Oranges</td>
                                <td id="uom_f_3">lbs</td>
                                <td id="open_f_3">16.384</td>
                                <td id="purchases_f_3">768.512</td>
                                <td id="close_f_3">24.256</td>
                                <td id="usage_f_3">697.247</td>

                            </tr>
                            <tr>
                                <td id="desc_f_4">Bananas</td>
                                <td id="uom_f_4">lbs</td>
                                <td id="open_f_4">55.837</td>
                                <td id="purchases_f_4">318.593</td>
                                <td id="close_f_4">0.000</td>
                                <td id="usage_f_4">337.128</td>

                            </tr>
                            </tbody>
                        </table>
												<div id="hidden_form_container" style="display:none;"></div>
												<script>
												function postRefreshPage () {

													theForm = document.createElement('form');
													theForm.action = 'create_post.php';
													theForm.method = 'post';

												newMeat1 = document.createElement('input');
												newMeat1.type = 'hidden';
												newMeat1.name = 'desc_m_1';
												newMeat1.value = document.getElementById('desc_m_1').innerHTML;
												newMeat2 = document.createElement('input');
												newMeat2.type = 'hidden';
												newMeat2.name = 'uom_m_1';
												newMeat2.value = document.getElementById('uom_m_1').innerHTML;
												newMeat3 = document.createElement('input');
												newMeat3.type = 'hidden';
												newMeat3.name = 'open_m_1';
												newMeat3.value = document.getElementById('open_m_1').innerHTML;
												newMeat4 = document.createElement('input');
												newMeat4.type = 'hidden';
												newMeat4.name = 'purchases_m_1';
												newMeat4.value = document.getElementById('purchases_m_1').innerHTML;
												newMeat5 = document.createElement('input');
												newMeat5.type = 'hidden';
												newMeat5.name = 'close_m_1';
												newMeat5.value = document.getElementById('close_m_1').innerHTML;
												newMeat6 = document.createElement('input');
												newMeat6.type = 'hidden';
												newMeat6.name = 'usage_m_1';
												newMeat6.value = document.getElementById('usage_m_1').innerHTML;

												newMeat7 = document.createElement('input');
												newMeat7.type = 'hidden';
												newMeat7.name = 'desc_m_2';
												newMeat7.value = document.getElementById('desc_m_2').innerHTML;
												newMeat8 = document.createElement('input');
												newMeat8.type = 'hidden';
												newMeat8.name = 'uom_m_2';
												newMeat8.value = document.getElementById('uom_m_2').innerHTML;
												newMeat9 = document.createElement('input');
												newMeat9.type = 'hidden';
												newMeat9.name = 'open_m_2';
												newMeat9.value = document.getElementById('open_m_2').innerHTML;
												newMeat10 = document.createElement('input');
												newMeat10.type = 'hidden';
												newMeat10.name = 'purchases_m_2';
												newMeat10.value = document.getElementById('purchases_m_2').innerHTML;
												newMeat11 = document.createElement('input');
												newMeat11.type = 'hidden';
												newMeat11.name = 'close_m_2';
												newMeat11.value = document.getElementById('close_m_2').innerHTML;
												newMeat12 = document.createElement('input');
												newMeat12.type = 'hidden';
												newMeat12.name = 'usage_m_2';
												newMeat12.value = document.getElementById('usage_m_2').innerHTML;

												newMeat13 = document.createElement('input');
												newMeat13.type = 'hidden';
												newMeat13.name = 'desc_m_3';
												newMeat13.value = document.getElementById('desc_m_3').innerHTML;
												newMeat14 = document.createElement('input');
												newMeat14.type = 'hidden';
												newMeat14.name = 'uom_m_3';
												newMeat14.value = document.getElementById('uom_m_3').innerHTML;
												newMeat15 = document.createElement('input');
												newMeat15.type = 'hidden';
												newMeat15.name = 'open_m_3';
												newMeat15.value = document.getElementById('open_m_3').innerHTML;
												newMeat16 = document.createElement('input');
												newMeat16.type = 'hidden';
												newMeat16.name = 'purchases_m_3';
												newMeat16.value = document.getElementById('purchases_m_3').innerHTML;
												newMeat17 = document.createElement('input');
												newMeat17.type = 'hidden';
												newMeat17.name = 'close_m_3';
												newMeat17.value = document.getElementById('close_m_3').innerHTML;
												newMeat18 = document.createElement('input');
												newMeat18.type = 'hidden';
												newMeat18.name = 'usage_m_3';
												newMeat18.value = document.getElementById('usage_m_3').innerHTML;

												newMeat19 = document.createElement('input');
												newMeat19.type = 'hidden';
												newMeat19.name = 'desc_m_4';
												newMeat19.value = document.getElementById('desc_m_4').innerHTML;
												newMeat20 = document.createElement('input');
												newMeat20.type = 'hidden';
												newMeat20.name = 'uom_m_4';
												newMeat20.value = document.getElementById('uom_m_4').innerHTML;
												newMeat21 = document.createElement('input');
												newMeat21.type = 'hidden';
												newMeat21.name = 'open_m_4';
												newMeat21.value = document.getElementById('open_m_4').innerHTML;
												newMeat22 = document.createElement('input');
												newMeat22.type = 'hidden';
												newMeat22.name = 'purchases_m_4';
												newMeat22.value = document.getElementById('purchases_m_4').innerHTML;
												newMeat23 = document.createElement('input');
												newMeat23.type = 'hidden';
												newMeat23.name = 'close_m_4';
												newMeat23.value = document.getElementById('close_m_4').innerHTML;
												newMeat24 = document.createElement('input');
												newMeat24.type = 'hidden';
												newMeat24.name = 'usage_m_4';
												newMeat24.value = document.getElementById('usage_m_4').innerHTML;



												newVeg1 = document.createElement('input');
												newVeg1.type = 'hidden';
												newVeg1.name = 'desc_v_1';
												newVeg1.value = document.getElementById('desc_v_1').innerHTML;
												newVeg2 = document.createElement('input');
												newVeg2.type = 'hidden';
												newVeg2.name = 'uom_v_1';
												newVeg2.value = document.getElementById('uom_v_1').innerHTML;
												newVeg3 = document.createElement('input');
												newVeg3.type = 'hidden';
												newVeg3.name = 'open_v_1';
												newVeg3.value = document.getElementById('open_v_1').innerHTML;
												newVeg4 = document.createElement('input');
												newVeg4.type = 'hidden';
												newVeg4.name = 'purchases_v_1';
												newVeg4.value = document.getElementById('purchases_v_1').innerHTML;
												newVeg5 = document.createElement('input');
												newVeg5.type = 'hidden';
												newVeg5.name = 'close_v_1';
												newVeg5.value = document.getElementById('close_v_1').innerHTML;
												newVeg6 = document.createElement('input');
												newVeg6.type = 'hidden';
												newVeg6.name = 'usage_v_1';
												newVeg6.value = document.getElementById('usage_v_1').innerHTML;

												newVeg7 = document.createElement('input');
												newVeg7.type = 'hidden';
												newVeg7.name = 'desc_v_2';
												newVeg7.value = document.getElementById('desc_v_2').innerHTML;
												newVeg8 = document.createElement('input');
												newVeg8.type = 'hidden';
												newVeg8.name = 'uom_v_2';
												newVeg8.value = document.getElementById('uom_v_2').innerHTML;
												newVeg9 = document.createElement('input');
												newVeg9.type = 'hidden';
												newVeg9.name = 'open_v_2';
												newVeg9.value = document.getElementById('open_v_2').innerHTML;
												newVeg10 = document.createElement('input');
												newVeg10.type = 'hidden';
												newVeg10.name = 'purchases_v_2';
												newVeg10.value = document.getElementById('purchases_v_2').innerHTML;
												newVeg11 = document.createElement('input');
												newVeg11.type = 'hidden';
												newVeg11.name = 'close_v_2';
												newVeg11.value = document.getElementById('close_v_2').innerHTML;
												newVeg12 = document.createElement('input');
												newVeg12.type = 'hidden';
												newVeg12.name = 'usage_v_2';
												newVeg12.value = document.getElementById('usage_v_2').innerHTML;

												newVeg13 = document.createElement('input');
												newVeg13.type = 'hidden';
												newVeg13.name = 'desc_v_3';
												newVeg13.value = document.getElementById('desc_v_3').innerHTML;
												newVeg14 = document.createElement('input');
												newVeg14.type = 'hidden';
												newVeg14.name = 'uom_v_3';
												newVeg14.value = document.getElementById('uom_v_3').innerHTML;
												newVeg15 = document.createElement('input');
												newVeg15.type = 'hidden';
												newVeg15.name = 'open_v_3';
												newVeg15.value = document.getElementById('open_v_3').innerHTML;
												newVeg16 = document.createElement('input');
												newVeg16.type = 'hidden';
												newVeg16.name = 'purchases_v_3';
												newVeg16.value = document.getElementById('purchases_v_3').innerHTML;
												newVeg17 = document.createElement('input');
												newVeg17.type = 'hidden';
												newVeg17.name = 'close_v_3';
												newVeg17.value = document.getElementById('close_v_3').innerHTML;
												newVeg18 = document.createElement('input');
												newVeg18.type = 'hidden';
												newVeg18.name = 'usage_v_3';
												newVeg18.value = document.getElementById('usage_v_3').innerHTML;

												newVeg19 = document.createElement('input');
												newVeg19.type = 'hidden';
												newVeg19.name = 'desc_v_4';
												newVeg19.value = document.getElementById('desc_v_4').innerHTML;
												newVeg20 = document.createElement('input');
												newVeg20.type = 'hidden';
												newVeg20.name = 'uom_v_4';
												newVeg20.value = document.getElementById('uom_v_4').innerHTML;
												newVeg21 = document.createElement('input');
												newVeg21.type = 'hidden';
												newVeg21.name = 'open_v_4';
												newVeg21.value = document.getElementById('open_v_4').innerHTML;
												newVeg22 = document.createElement('input');
												newVeg22.type = 'hidden';
												newVeg22.name = 'purchases_v_4';
												newVeg22.value = document.getElementById('purchases_v_4').innerHTML;
												newVeg23 = document.createElement('input');
												newVeg23.type = 'hidden';
												newVeg23.name = 'close_v_4';
												newVeg23.value = document.getElementById('close_v_4').innerHTML;
												newVeg24 = document.createElement('input');
												newVeg24.type = 'hidden';
												newVeg24.name = 'usage_v_4';
												newVeg24.value = document.getElementById('usage_v_4').innerHTML;



												newFrt1 = document.createElement('input');
												newFrt1.type = 'hidden';
												newFrt1.name = 'desc_f_1';
												newFrt1.value = document.getElementById('desc_f_1').innerHTML;
												newFrt2 = document.createElement('input');
												newFrt2.type = 'hidden';
												newFrt2.name = 'uom_f_1';
												newFrt2.value = document.getElementById('uom_f_1').innerHTML;
												newFrt3 = document.createElement('input');
												newFrt3.type = 'hidden';
												newFrt3.name = 'open_f_1';
												newFrt3.value = document.getElementById('open_f_1').innerHTML;
												newFrt4 = document.createElement('input');
												newFrt4.type = 'hidden';
												newFrt4.name = 'purchases_f_1';
												newFrt4.value = document.getElementById('purchases_f_1').innerHTML;
												newFrt5 = document.createElement('input');
												newFrt5.type = 'hidden';
												newFrt5.name = 'close_f_1';
												newFrt5.value = document.getElementById('close_f_1').innerHTML;
												newFrt6 = document.createElement('input');
												newFrt6.type = 'hidden';
												newFrt6.name = 'usage_f_1';
												newFrt6.value = document.getElementById('usage_f_1').innerHTML;

												newFrt7 = document.createElement('input');
												newFrt7.type = 'hidden';
												newFrt7.name = 'desc_f_2';
												newFrt7.value = document.getElementById('desc_f_2').innerHTML;
												newFrt8 = document.createElement('input');
												newFrt8.type = 'hidden';
												newFrt8.name = 'uom_f_2';
												newFrt8.value = document.getElementById('uom_f_2').innerHTML;
												newFrt9 = document.createElement('input');
												newFrt9.type = 'hidden';
												newFrt9.name = 'open_f_2';
												newFrt9.value = document.getElementById('open_f_2').innerHTML;
												newFrt10 = document.createElement('input');
												newFrt10.type = 'hidden';
												newFrt10.name = 'purchases_f_2';
												newFrt10.value = document.getElementById('purchases_f_2').innerHTML;
												newFrt11 = document.createElement('input');
												newFrt11.type = 'hidden';
												newFrt11.name = 'close_f_2';
												newFrt11.value = document.getElementById('close_f_2').innerHTML;
												newFrt12 = document.createElement('input');
												newFrt12.type = 'hidden';
												newFrt12.name = 'usage_f_2';
												newFrt12.value = document.getElementById('usage_f_2').innerHTML;

												newFrt13 = document.createElement('input');
												newFrt13.type = 'hidden';
												newFrt13.name = 'desc_f_3';
												newFrt13.value = document.getElementById('desc_f_3').innerHTML;
												newFrt14 = document.createElement('input');
												newFrt14.type = 'hidden';
												newFrt14.name = 'uom_f_3';
												newFrt14.value = document.getElementById('uom_f_3').innerHTML;
												newFrt15 = document.createElement('input');
												newFrt15.type = 'hidden';
												newFrt15.name = 'open_f_3';
												newFrt15.value = document.getElementById('open_f_3').innerHTML;
												newFrt16 = document.createElement('input');
												newFrt16.type = 'hidden';
												newFrt16.name = 'purchases_f_3';
												newFrt16.value = document.getElementById('purchases_f_3').innerHTML;
												newFrt17 = document.createElement('input');
												newFrt17.type = 'hidden';
												newFrt17.name = 'close_f_3';
												newFrt17.value = document.getElementById('close_f_3').innerHTML;
												newFrt18 = document.createElement('input');
												newFrt18.type = 'hidden';
												newFrt18.name = 'usage_f_3';
												newFrt18.value = document.getElementById('usage_f_3').innerHTML;

												newFrt19 = document.createElement('input');
												newFrt19.type = 'hidden';
												newFrt19.name = 'desc_f_4';
												newFrt19.value = document.getElementById('desc_f_4').innerHTML;
												newFrt20 = document.createElement('input');
												newFrt20.type = 'hidden';
												newFrt20.name = 'uom_f_4';
												newFrt20.value = document.getElementById('uom_f_4').innerHTML;
												newFrt21 = document.createElement('input');
												newFrt21.type = 'hidden';
												newFrt21.name = 'open_f_4';
												newFrt21.value = document.getElementById('open_f_4').innerHTML;
												newFrt22 = document.createElement('input');
												newFrt22.type = 'hidden';
												newFrt22.name = 'purchases_f_4';
												newFrt22.value = document.getElementById('purchases_f_4').innerHTML;
												newFrt23 = document.createElement('input');
												newFrt23.type = 'hidden';
												newFrt23.name = 'close_f_4';
												newFrt23.value = document.getElementById('close_f_4').innerHTML;
												newFrt24 = document.createElement('input');
												newFrt24.type = 'hidden';
												newFrt24.name = 'usage_f_4';
												newFrt24.value = document.getElementById('usage_f_4').innerHTML;

												for (var i = 1; i < 25; i++) {
												  theForm.appendChild(eval("newMeat" + i));
												}

												for (var i = 1; i < 25; i++) {
												  theForm.appendChild(eval("newVeg" + i));
												}

												for (var i = 1; i < 25; i++) {
												  theForm.appendChild(eval("newFrt" + i));
												}

												// ...and it to the DOM...
												document.getElementById('hidden_form_container').appendChild(theForm);
												// ...and submit it
												theForm.submit();
												}
												//postRefreshPage();
											//window.location.href = "weeklylog.php";
											//


												</script>
												<input type="button" value="Submit" onclick="window.open('weeklylog.php','_blank');postRefreshPage();">
											</form>
                </div>

                <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
                <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
                <script src="bootstable.js"></script>

                <script>
                    $('#makeEditable').SetEditable({ $addButton: $('#but_add')});
                </script>

                <script>
                    $('#makeEditable2').SetEditable({ $addButton: $('#but_add2')});
                </script>

                <script>
                    $('#makeEditable3').SetEditable({ $addButton: $('#but_add3')});
                </script>

            </div>
        </div>


        <footer class="footer">
            <div class="container-fluid">
                <nav class="pull-left">
                    <ul>

                        <li>
                            <a href="http://www.iqfoodco.com/">
                                IQ Food Store
                            </a>
                        </li>
                        <li>
                            <a href="">
                               Blog
                            </a>
                        </li>
                    </ul>
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script>, made with <a href="http://www.creative-tim.com"> IQ Foods</a>
                </div>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="../assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="../assets/js/bootstrap-checkbox-radio.js"></script>

	<!--  Charts Plugin -->
	<script src="../assets/js/chartist.min.js"></script>
    <script src="../assets/js/inventoryCode.js"></script>
    <!--  Notifications Plugin    -->
    <script src="../assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>

    <!-- Paper Dashboard Core javascript and methods for Demo purpose -->
	<script src="../assets/js/paper-dashboard.js"></script>

	<!-- Paper Dashboard DEMO methods, don't include it in your project! -->
	<script src="../assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){

        	demo.initChartist();

        	$.notify({
            	icon: 'ti-agenda',
            	message: "Welcome to <b>Weekly log Page</b> - (Notification of past activites will go here)."

            },{
                type: 'success',
                timer: 40
            });

    	});
	</script>

</html>
