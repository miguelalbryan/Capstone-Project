var base64Img = null;

var pdf = {};

pdf.wk = function (i) {
    var doc = new jsPDF('l');
    doc.text("iQ Foods - Week " + i + " Report", 15, 15);
    var elem = document.getElementById("meat-table-" + i);
    var res = doc.autoTableHtmlToJson(elem);
    doc.text("Meat", 15, 30);
    doc.autoTable(res.columns, res.data, {startY: 35, theme: 'grid', headerStyles: {fillColor: [255, 112, 67]}});
    var elem2 = document.getElementById("veg-table-" + i);
    var res2 = doc.autoTableHtmlToJson(elem2);
    doc.text("Vegetables", 15, doc.autoTable.previous.finalY + 10);
    doc.autoTable(res2.columns, res2.data, {startY: doc.autoTable.previous.finalY + 15, theme: 'grid', headerStyles: {fillColor: [102, 187, 106]}});
    var elem3 = document.getElementById("frt-table-" + i);
    var res3 = doc.autoTableHtmlToJson(elem3);
    doc.text("Fruits", 15, doc.autoTable.previous.finalY + 10);
    doc.autoTable(res3.columns, res3.data, {startY: doc.autoTable.previous.finalY + 15, theme: 'grid', headerStyles: {fillColor: [255, 167, 38]}});

    return doc;
};

//helper functions

imgToBase64('document.jpg', function(base64) {
    base64Img = base64;
});

function imgToBase64(url, callback) {
    if (!window.FileReader) {
        callback(null);
        return;
    }
    var xhr = new XMLHttpRequest();
    xhr.responseType = 'blob';
    xhr.onload = function() {
        var reader = new FileReader();
        reader.onloadend = function() {
            callback(reader.result.replace('text/xml', 'image/jpeg'));
        };
        reader.readAsDataURL(xhr.response);
    };
    xhr.open('GET', url);
    xhr.send();
}
